@echo off
start "" "%~dp0AI-Assistant.exe" -ball
