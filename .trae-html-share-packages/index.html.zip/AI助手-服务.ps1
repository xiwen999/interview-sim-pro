﻿$ErrorActionPreference = 'Stop'

# ============================================================
# AI 桌面助手 · 后台服务
# 常驻运行：持有网页设置接口，并负责启动 / 关闭悬浮球进程。
# 悬浮球脚本：AI助手-桌面球.ps1
# 网页设置接口：http://127.0.0.1:47821/settings
# ============================================================

$script:selfPath = $MyInvocation.MyCommand.Path
$script:root = Split-Path -Parent $script:selfPath
$script:ballScript = Join-Path $script:root 'AI助手-桌面球.ps1'
$script:launcher = Join-Path $script:root 'AI-Assistant.exe'
$script:cfgDir = Join-Path $env:APPDATA 'InterviewAI'
if (!(Test-Path $script:cfgDir)) { New-Item -ItemType Directory -Path $script:cfgDir -Force | Out-Null }
$script:cfgFile = Join-Path $script:cfgDir 'settings.txt'
$script:startupLnk = Join-Path ([Environment]::GetFolderPath('Startup')) 'AI面试助手桌面球.lnk'
$script:taskName = 'InterviewAI_DesktopAssistant'

# 单实例：避免重复启动
$mutex = New-Object System.Threading.Mutex($false, 'InterviewAI_DesktopService')
$got = $false
try { $got = $mutex.WaitOne(0) } catch { $got = $true }
if (-not $got) { exit }

$script:autoHide = $true
$script:autoStart = $true
$script:enabled = $true

function LoadCfg {
  if (!(Test-Path $script:cfgFile)) { return }
  foreach ($line in (Get-Content $script:cfgFile -ErrorAction SilentlyContinue)) {
    foreach ($pair in ($line -split '\s+')) {
      $kv = $pair.Split('=')
      if ($kv.Length -ge 2) {
        $k = $kv[0].Trim()
        $v = ($kv[1..($kv.Length - 1)] -join '=').Trim()
        switch ($k) {
          'autoHide' { $script:autoHide = ($v -eq '1') }
          'autoStart' { $script:autoStart = ($v -eq '1') }
          'enabled' { $script:enabled = ($v -eq '1') }
        }
      }
    }
  }
}

function SaveCfg {
  $h = if ($script:autoHide) { '1' } else { '0' }
  $s = if ($script:autoStart) { '1' } else { '0' }
  $e = if ($script:enabled) { '1' } else { '0' }
  $txt = 'autoHide=' + $h + "`r`n" + 'autoStart=' + $s + "`r`n" + 'enabled=' + $e + "`r`n"
  try {
    [IO.File]::WriteAllText($script:cfgFile, $txt, (New-Object System.Text.UTF8Encoding($true)))
  } catch {
    try { Set-Content -Path $script:cfgFile -Value $txt -Encoding UTF8 } catch {}
  }
}

function EnsureStartup {
  try {
    $exe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $arg = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $script:selfPath + '"'
    if (Test-Path $script:launcher) {
      # 用无控制台的启动器运行，避免任务栏里出现控制台窗口
      $exe = $script:launcher
      $arg = '-service'
    }
    if ($script:autoStart) {
      # 用计划任务保证常驻：登录时启动，并且每分钟检查一次（进程被结束后自动拉起）
      $need = $true
      try {
        $t = Get-ScheduledTask -TaskName $script:taskName -ErrorAction Stop
        $act = $t.Actions | Select-Object -First 1
        if ($act -and $act.Execute -eq $exe -and ([string]$act.Arguments) -eq $arg -and $t.Triggers.Count -ge 2) { $need = $false }
      } catch { $need = $true }
      if ($need) {
        $action = New-ScheduledTaskAction -Execute $exe -Argument $arg -WorkingDirectory $script:root
        $triggers = @(
          (New-ScheduledTaskTrigger -AtLogOn),
          (New-ScheduledTaskTrigger -Once -At ((Get-Date).AddMinutes(1)) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration (New-TimeSpan -Days 3650))
        )
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
        $user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
        Register-ScheduledTask -TaskName $script:taskName -Action $action -Trigger $triggers -Settings $settings -Principal $principal -Force | Out-Null
      }
    } else {
      Unregister-ScheduledTask -TaskName $script:taskName -Confirm:$false -ErrorAction SilentlyContinue
    }
    # 旧的“启动文件夹快捷方式”统一清理，避免重复启动
    if (Test-Path $script:startupLnk) { Remove-Item -Path $script:startupLnk -Force -ErrorAction SilentlyContinue }
  } catch {}
}

# ---------------- 悬浮球进程管理 ----------------
function GetBallProcs {
  $me = $PID
  try {
    $list = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object {
      ($_.ProcessId -ne $me) -and $_.CommandLine -and $_.CommandLine.Contains($script:ballScript)
    })
    return $list
  } catch {
    return @()
  }
}

function StartBall {
  try {
    if (Test-Path $script:launcher) {
      $psi = New-Object System.Diagnostics.ProcessStartInfo
      $psi.FileName = $script:launcher
      $psi.Arguments = '-ball'
      $psi.WorkingDirectory = $script:root
      $psi.UseShellExecute = $false
      $psi.CreateNoWindow = $true
      [System.Diagnostics.Process]::Start($psi) | Out-Null
      return
    }
  } catch {}
  try {
    $exe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $cmd = '"' + $exe + '" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $script:ballScript + '"'
    Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cmd; CurrentDirectory = $script:root } | Out-Null
  } catch {}
}

function StopBall {
  foreach ($p in (GetBallProcs)) {
    try { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue } catch {}
  }
}

# ---------------- 网页设置接口（仅监听本机 127.0.0.1） ----------------
$script:apiPort = 47821
$script:api = $null
$script:apiTask = $null

function StartApi {
  try {
    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add('http://127.0.0.1:' + $script:apiPort + '/')
    $listener.Start()
    $script:api = $listener
    $script:apiTask = $listener.GetContextAsync()
  } catch {
    $script:api = $null
    $script:apiTask = $null
  }
}

function SendApiJson($ctx, $obj, $code) {
  try {
    $json = $obj | ConvertTo-Json -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $ctx.Response.StatusCode = $code
    $ctx.Response.ContentType = 'application/json; charset=utf-8'
    $ctx.Response.Headers.Set('Access-Control-Allow-Origin', '*')
    $ctx.Response.Headers.Set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    $ctx.Response.Headers.Set('Access-Control-Allow-Headers', 'Content-Type')
    $ctx.Response.Headers.Set('Access-Control-Allow-Private-Network', 'true')
    $ctx.Response.Headers.Set('Cache-Control', 'no-store')
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  } catch {}
  try { $ctx.Response.Close() } catch {}
}

function GetState {
  $b = @(GetBallProcs)
  return [pscustomobject]@{
    running = $true
    enabled = [bool]$script:enabled
    ball = ($b.Count -gt 0)
    autoHide = [bool]$script:autoHide
    autoStart = [bool]$script:autoStart
  }
}

function HandleApi {
  if (-not $script:api -or -not $script:apiTask) { return }
  if (-not $script:apiTask.IsCompleted) { return }
  $ctx = $null
  try {
    $ctx = $script:apiTask.Result
    $req = $ctx.Request
    $path = $req.Url.AbsolutePath.TrimEnd('/')
    if ($req.HttpMethod -eq 'OPTIONS') {
      try {
        $ctx.Response.StatusCode = 204
        $ctx.Response.Headers.Set('Access-Control-Allow-Origin', '*')
        $ctx.Response.Headers.Set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        $ctx.Response.Headers.Set('Access-Control-Allow-Headers', 'Content-Type')
        $ctx.Response.Headers.Set('Access-Control-Allow-Private-Network', 'true')
        $ctx.Response.Close()
      } catch {}
    } elseif ($req.HttpMethod -eq 'GET' -and $path -eq '/settings') {
      SendApiJson $ctx (GetState) 200
    } elseif ($req.HttpMethod -eq 'POST' -and $path -eq '/settings') {
      $reader = New-Object System.IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
      $body = $reader.ReadToEnd()
      $reader.Close()
      $obj = $null
      try { $obj = $body | ConvertFrom-Json } catch { $obj = $null }
      if ($obj) {
        if ($null -ne $obj.autoHide) { $script:autoHide = [bool]$obj.autoHide }
        if ($null -ne $obj.autoStart) { $script:autoStart = [bool]$obj.autoStart }
        if ($null -ne $obj.enabled) { $script:enabled = [bool]$obj.enabled }
        SaveCfg
        EnsureStartup
        if ($script:enabled) {
          if (@(GetBallProcs).Count -eq 0) { StartBall }
        } else {
          StopBall
        }
      }
      SendApiJson $ctx (GetState) 200
    } else {
      SendApiJson $ctx ([pscustomobject]@{ error = 'not found' }) 404
    }
  } catch {
    try { if ($ctx) { $ctx.Response.Close() } } catch {}
  }
  try {
    if ($script:api -and $script:api.IsListening) { $script:apiTask = $script:api.GetContextAsync() }
  } catch { $script:apiTask = $null }
}

# ---------------- 启动 ----------------
LoadCfg
EnsureStartup
StartApi
if ($script:enabled) { StartBall }

$script:tick = 0
while ($true) {
  LoadCfg
  if (-not $script:api) { StartApi }
  HandleApi
  # 每 3 次轮询检查一次悬浮球进程，意外退出时自动拉起
  if (($script:tick % 3) -eq 0) {
    $b = @(GetBallProcs)
    if ($script:enabled -and $b.Count -eq 0) { StartBall }
  }
  $script:tick++
  Start-Sleep -Milliseconds 500
}
