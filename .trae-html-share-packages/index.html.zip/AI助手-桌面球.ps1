﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class W32A {
  public delegate bool EnumProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr lParam);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder sb, int max);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int X, int Y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
}
"@
[W32A]::SetProcessDPIAware() | Out-Null

$mutex = New-Object System.Threading.Mutex($false, 'InterviewAI_DesktopBall')
$got = $false
try { $got = $mutex.WaitOne(0) } catch { $got = $true }
if (-not $got) { exit }

$script:cfgDir = Join-Path $env:APPDATA 'InterviewAI'
if (!(Test-Path $script:cfgDir)) { New-Item -ItemType Directory -Path $script:cfgDir -Force | Out-Null }
$script:cfgFile = Join-Path $script:cfgDir 'settings.txt'
$script:posFile = Join-Path $script:cfgDir 'ballpos.txt'

$script:autoHide = $true
$script:autoStart = $true
$script:enabled = $true
if (Test-Path $script:cfgFile) {
  foreach ($line in (Get-Content $script:cfgFile -ErrorAction SilentlyContinue)) {
    foreach ($pair in ($line -split '\s+')) {
      $kv = $pair.Split('=')
      if ($kv.Length -ge 2) {
        $k = $kv[0].Trim(); $v = ($kv[1..($kv.Length-1)] -join '=').Trim()
        switch ($k) {
          'autoHide' { $script:autoHide = ($v -eq '1') }
          'autoStart' { $script:autoStart = ($v -eq '1') }
          'enabled' { $script:enabled = ($v -eq '1') }
        }
      }
    }
  }
}

function SaveCfg {
  $h = if ($script:autoHide) { '1' } else { '0' }
  $s = if ($script:autoStart) { '1' } else { '0' }
  $e = if ($script:enabled) { '1' } else { '0' }
  $txt = 'autoHide=' + $h + "`r`n" + 'autoStart=' + $s + "`r`n" + 'enabled=' + $e + "`r`n"
  try {
    [IO.File]::WriteAllText($script:cfgFile, $txt, (New-Object System.Text.UTF8Encoding($true)))
  } catch {
    Set-Content -Path $script:cfgFile -Value $txt -Encoding UTF8
  }
}

# 悬浮球被启动（服务拉起或手动启动）即视为桌面助手已开启
$script:enabled = $true
SaveCfg

function RefreshCfg {
  if (!(Test-Path $script:cfgFile)) { return }
  foreach ($line in (Get-Content $script:cfgFile -ErrorAction SilentlyContinue)) {
    foreach ($pair in ($line -split '\s+')) {
      $kv = $pair.Split('=')
      if ($kv.Length -ge 2) {
        $k = $kv[0].Trim(); $v = ($kv[1..($kv.Length-1)] -join '=').Trim()
        if ($k -eq 'autoHide') { $script:autoHide = ($v -eq '1') }
        elseif ($k -eq 'autoStart') { $script:autoStart = ($v -eq '1') }
      }
    }
  }
}

$C_BG = [System.Drawing.Color]::FromArgb(15, 21, 42)
$C_LINE = [System.Drawing.Color]::FromArgb(43, 53, 84)
$C_INK = [System.Drawing.Color]::FromArgb(238, 242, 255)
$C_INK2 = [System.Drawing.Color]::FromArgb(170, 180, 216)
$C_INK3 = [System.Drawing.Color]::FromArgb(124, 134, 173)
$C_ACC = [System.Drawing.Color]::FromArgb(108, 140, 255)
$C_ACC2 = [System.Drawing.Color]::FromArgb(65, 224, 200)
$C_ME = [System.Drawing.Color]::FromArgb(79, 110, 240)
$C_BOT = [System.Drawing.Color]::FromArgb(28, 37, 64)
$C_RED = [System.Drawing.Color]::FromArgb(251, 113, 133)

$script:fntTitle = New-Object System.Drawing.Font('Microsoft YaHei UI', 13, [System.Drawing.FontStyle]::Bold)
$script:fntMsg = New-Object System.Drawing.Font('Microsoft YaHei UI', 10.5)
$script:fntSmall = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
$script:fntChip = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
$script:fntClose = New-Object System.Drawing.Font('Microsoft YaHei UI', 11)

function NewRoundPath([single]$x, [single]$y, [single]$w, [single]$h, [single]$r) {
  $p = New-Object System.Drawing.Drawing2D.GraphicsPath
  $p.AddArc($x, $y, $r, $r, 180, 90)
  $p.AddArc($x + $w - $r, $y, $r, $r, 270, 90)
  $p.AddArc($x + $w - $r, $y + $h - $r, $r, $r, 0, 90)
  $p.AddArc($x, $y + $h - $r, $r, $r, 90, 90)
  $p.CloseFigure()
  return $p
}

function DrawRobot($g, [single]$cx, [single]$cy, [single]$size, [System.Drawing.Color]$color) {
  $s = $size / 24.0
  $x0 = $cx - 12 * $s
  $y0 = $cy - 12 * $s
  $pen = New-Object System.Drawing.Pen($color, [single](0.085 * $size))
  $rp = NewRoundPath ($x0 + 4 * $s) ($y0 + 8 * $s) (16 * $s) (12 * $s) (3 * $s)
  $g.DrawPath($pen, $rp)
  $g.DrawLine($pen, [single]($x0 + 12 * $s), [single]($y0 + 8 * $s), [single]($x0 + 12 * $s), [single]($y0 + 4 * $s))
  $g.DrawLine($pen, [single]($x0 + 8 * $s), [single]($y0 + 4 * $s), [single]($x0 + 16 * $s), [single]($y0 + 4 * $s))
  $eye = New-Object System.Drawing.SolidBrush($color)
  $r = [single](1.35 * $s)
  $g.FillEllipse($eye, [single]($x0 + 9 * $s - $r), [single]($y0 + 13 * $s - $r), [single](2 * $r), [single](2 * $r))
  $g.FillEllipse($eye, [single]($x0 + 15 * $s - $r), [single]($y0 + 13 * $s - $r), [single](2 * $r), [single](2 * $r))
  $g.DrawLine($pen, [single]($x0 + 9.5 * $s), [single]($y0 + 16.5 * $s), [single]($x0 + 14.5 * $s), [single]($y0 + 16.5 * $s))
  $pen.Dispose(); $rp.Dispose(); $eye.Dispose()
}

# ---------------- 悬浮球 ----------------
$BS = 84
$script:dot = $true
$script:ball = New-Object System.Windows.Forms.Form
$script:ball.Text = 'AI 桌面助手'
$script:ball.FormBorderStyle = 'None'
$script:ball.StartPosition = 'Manual'
$script:ball.TopMost = $true
$script:ball.ShowInTaskbar = $false
$script:ball.MinimumSize = New-Object System.Drawing.Size(1, 1)
$script:ball.Width = $BS
$script:ball.Height = $BS
$script:ball.BackColor = [System.Drawing.Color]::FromArgb(10, 18, 36)
$script:ball.Cursor = [System.Windows.Forms.Cursors]::Hand
$rpBall = New-Object System.Drawing.Drawing2D.GraphicsPath
$rpBall.AddEllipse(0, 0, $BS, $BS)
$script:ball.Region = New-Object System.Drawing.Region($rpBall)
$rpBall.Dispose()

$script:ball.Add_Paint({
  param($s, $e)
  $g = $e.Graphics
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.FillEllipse((New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(20, 30, 60))), 0, 0, $BS, $BS)
  $inner = New-Object System.Drawing.Rectangle(5, 5, ($BS - 10), ($BS - 10))
  $grad = New-Object System.Drawing.Drawing2D.LinearGradientBrush($inner, $C_ACC, $C_ACC2, 45)
  $ip = New-Object System.Drawing.Drawing2D.GraphicsPath
  $ip.AddEllipse(5, 5, ($BS - 10), ($BS - 10))
  $g.FillPath($grad, $ip)
  $ring = New-Object System.Drawing.Pen([System.Drawing.Color]::White, 3)
  $g.DrawEllipse($ring, 4, 4, ($BS - 8), ($BS - 8))
  DrawRobot $g ($BS / 2) ($BS / 2) 34 ([System.Drawing.Color]::White)
  if ($script:dot) {
    $ring2 = New-Object System.Drawing.Pen([System.Drawing.Color]::White, 2)
    $g.FillEllipse((New-Object System.Drawing.SolidBrush($C_RED)), ($BS - 20), 5, 13, 13)
    $g.DrawEllipse($ring2, ($BS - 20), 5, 13, 13)
    $ring2.Dispose()
  }
  $ring.Dispose(); $grad.Dispose(); $ip.Dispose()
})

$vs = [System.Windows.Forms.SystemInformation]::VirtualScreen
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$bx = $wa.Right - 108
$by = $wa.Bottom - 108
if (Test-Path $script:posFile) {
  $parts = (Get-Content $script:posFile -Raw).Trim().Split(',')
  if ($parts.Length -eq 2) { $bx = [int]$parts[0]; $by = [int]$parts[1] }
}
$bx = [Math]::Max($vs.Left + 6, [Math]::Min($bx, $vs.Right - $BS - 6))
$by = [Math]::Max($vs.Top + 6, [Math]::Min($by, $vs.Bottom - $BS - 6))
$script:ball.Location = New-Object System.Drawing.Point($bx, $by)

$script:drag = $false
$script:moved = $false
$script:sx = 0; $script:sy = 0; $script:ox = 0; $script:oy = 0
$script:ball.Add_MouseDown({
  param($s, $e)
  if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Left) {
    $script:drag = $true; $script:moved = $false
    $p = [System.Windows.Forms.Cursor]::Position
    $script:sx = $p.X; $script:sy = $p.Y
    $script:ox = $script:ball.Left; $script:oy = $script:ball.Top
  }
})
$script:ball.Add_MouseMove({
  param($s, $e)
  if ($script:drag) {
    $p = [System.Windows.Forms.Cursor]::Position
    $dx = $p.X - $script:sx; $dy = $p.Y - $script:sy
    if ([Math]::Abs($dx) + [Math]::Abs($dy) -gt 4) { $script:moved = $true }
    $script:ball.Left = $script:ox + $dx
    $script:ball.Top = $script:oy + $dy
    if ($script:panel.Visible) { PlacePanel }
  }
})

# ---------------- 助手面板 ----------------
$script:panel = New-Object System.Windows.Forms.Form
$script:panel.Text = 'IVSIM_ASSISTANT'
$script:panel.FormBorderStyle = 'None'
$script:panel.StartPosition = 'Manual'
$script:panel.TopMost = $true
$script:panel.ShowInTaskbar = $false
$script:panel.MinimumSize = New-Object System.Drawing.Size(1, 1)
$script:panel.Width = 520
$script:panel.Height = 660
$script:panel.BackColor = $C_BG
$script:panel.KeyPreview = $true
$script:panelP = NewRoundPath 0 0 520 660 18
$script:panel.Region = New-Object System.Drawing.Region($script:panelP)
$script:panelP.Dispose()

$script:msgs = @()
$script:mScroll = 0
$script:contentH = 0
$script:stickBottom = $true
$script:statusText = '● 在线 · 随时待命'
$script:pending = $null

function AddMsg([string]$text, [bool]$me) {
  $script:msgs += @{ me = $me; text = $text }
  $script:stickBottom = $true
  $script:ctxLbl.Text = '对话记录: ' + ($script:msgs.Count - 1)
  $script:mp.Invalidate()
}
function ResetMsgs {
  $script:msgs = @()
  $script:mScroll = 0
  AddMsg '嗨～我是 AI 面试助手，可以问我：怎么开始模拟面试、题库怎么用、语音作答、自评标准、复盘报告等问题。' $false
}

$script:panel.Add_KeyDown({
  param($s, $e)
  if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Escape) { $script:panel.Hide() }
})
$script:panel.Add_Paint({
  param($s, $e)
  $g = $e.Graphics
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $bp = NewRoundPath 0 0 ($s.Width - 1) ($s.Height - 1) 18
  $g.DrawPath((New-Object System.Drawing.Pen($C_LINE, 1)), $bp)
  $bp.Dispose()
})

$head = New-Object System.Windows.Forms.Panel
$head.Height = 76
$head.BackColor = $C_BG
$head.Add_Paint({
  param($s, $e)
  $g = $e.Graphics
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $rect = New-Object System.Drawing.Rectangle(0, 0, $s.Width, $s.Height)
  $gb = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, [System.Drawing.Color]::FromArgb(38, 52, 88), [System.Drawing.Color]::FromArgb(26, 58, 60), 0)
  $g.FillRectangle($gb, $rect)
  $g.DrawLine((New-Object System.Drawing.Pen($C_LINE, 1)), 0, ($s.Height - 1), $s.Width, ($s.Height - 1))
  $av = NewRoundPath 16 17 42 42 12
  $gb2 = New-Object System.Drawing.Drawing2D.LinearGradientBrush((New-Object System.Drawing.Rectangle(0, 0, 42, 42)), $C_ACC, $C_ACC2, 45)
  $g.FillPath($gb2, $av)
  DrawRobot $g 37 38 24 ([System.Drawing.Color]::White)
  [System.Windows.Forms.TextRenderer]::DrawText($g, 'AI 面试助手', $script:fntTitle, (New-Object System.Drawing.Rectangle(70, 13, 360, 28)), $C_INK, [System.Windows.Forms.TextFormatFlags]::NoPrefix)
  [System.Windows.Forms.TextRenderer]::DrawText($g, $script:statusText, $script:fntSmall, (New-Object System.Drawing.Rectangle(70, 41, 360, 22)), $C_ACC2, [System.Windows.Forms.TextFormatFlags]::NoPrefix)
  [System.Windows.Forms.TextRenderer]::DrawText($g, '✕', $script:fntClose, (New-Object System.Drawing.Rectangle(($s.Width - 54), 20, 36, 30)), $C_INK3, ([System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [System.Windows.Forms.TextFormatFlags]::VerticalCenter))
  $gb.Dispose(); $gb2.Dispose(); $av.Dispose()
})
$head.Add_MouseUp({
  param($s, $e)
  if ($e.X -gt ($s.Width - 60) -and $e.Y -lt 60) { $script:panel.Hide() }
})
$head.Cursor = [System.Windows.Forms.Cursors]::Hand

$script:mp = New-Object System.Windows.Forms.Panel
$script:mp.BackColor = $C_BG
$script:mp.Add_Paint({
  param($s, $e)
  $g = $e.Graphics
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $items = @()
  $y = 12
  foreach ($m in $script:msgs) {
    $maxW = if ($m.me) { 330 } else { 370 }
    $sz = [System.Windows.Forms.TextRenderer]::MeasureText($m.text, $script:fntMsg, (New-Object System.Drawing.Size($maxW, 2000)), [System.Windows.Forms.TextFormatFlags]::WordBreak)
    $w = [Math]::Min(($maxW + 24), ($sz.Width + 24))
    $h = $sz.Height + 18
    $x = if ($m.me) { $s.Width - 16 - $w } else { 16 }
    $items += @{ x = $x; y = $y; w = $w; h = $h; me = $m.me; text = $m.text }
    $y += $h + 10
  }
  $script:contentH = $y + 2
  $maxS = [Math]::Max(0, ($script:contentH - $s.Height))
  if ($script:stickBottom) { $script:mScroll = $maxS; $script:stickBottom = $false }
  if ($script:mScroll -gt $maxS) { $script:mScroll = $maxS }
  if ($script:mScroll -lt 0) { $script:mScroll = 0 }
  $off = $script:mScroll
  foreach ($it in $items) {
    $dy = $it.y - $off
    if (($dy + $it.h) -lt 0 -or $dy -gt $s.Height) { continue }
    $bp = NewRoundPath $it.x $dy $it.w $it.h 12
    if ($it.me) {
      $g.FillPath((New-Object System.Drawing.SolidBrush($C_ME)), $bp)
    } else {
      $g.FillPath((New-Object System.Drawing.SolidBrush($C_BOT)), $bp)
      $g.DrawPath((New-Object System.Drawing.Pen($C_LINE, 1)), $bp)
    }
    $fg = if ($it.me) { [System.Drawing.Color]::White } else { $C_INK }
    [System.Windows.Forms.TextRenderer]::DrawText($g, $it.text, $script:fntMsg, (New-Object System.Drawing.Rectangle(($it.x + 12), ($dy + 9), ($it.w - 24), ($it.h - 18))), $fg, ([System.Windows.Forms.TextFormatFlags]::WordBreak -bor [System.Windows.Forms.TextFormatFlags]::NoPrefix))
    $bp.Dispose()
  }
})
$script:mp.Add_MouseWheel({
  param($s, $e)
  $step = 60
  if ($e.Delta -gt 0) { $script:mScroll -= $step } else { $script:mScroll += $step }
  $maxS = [Math]::Max(0, ($script:contentH - $script:mp.Height))
  if ($script:mScroll -gt $maxS) { $script:mScroll = $maxS }
  if ($script:mScroll -lt 0) { $script:mScroll = 0 }
  $script:mp.Invalidate()
})

$quick = New-Object System.Windows.Forms.FlowLayoutPanel
$quick.Height = 46
$quick.BackColor = $C_BG
$quick.Padding = New-Object System.Windows.Forms.Padding(12, 6, 12, 6)
$chips = @(
  @{ t = '怎么开始'; q = '怎么开始模拟面试？' },
  @{ t = '题库'; q = '题库在哪里？' },
  @{ t = '语音作答'; q = '怎么用语音作答？' },
  @{ t = '缓解紧张'; q = '面试紧张怎么办？' }
)
foreach ($c in $chips) {
  $b = New-Object System.Windows.Forms.Button
  $b.Text = $c.t
  $b.Size = New-Object System.Drawing.Size(112, 30)
  $b.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
  $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $b.BackColor = [System.Drawing.Color]::FromArgb(30, 39, 66)
  $b.ForeColor = [System.Drawing.Color]::FromArgb(205, 216, 255)
  $b.FlatAppearance.BorderColor = $C_LINE
  $b.Font = $script:fntChip
  $b.Cursor = [System.Windows.Forms.Cursors]::Hand
  $b.Tag = $c.q
  $b.Add_Click({ param($s, $e) BeginAnswer ([string]$s.Tag) })
  $quick.Controls.Add($b)
}

$inputRow = New-Object System.Windows.Forms.Panel
$inputRow.Height = 60
$inputRow.BackColor = $C_BG
$script:tb = New-Object System.Windows.Forms.TextBox
$script:tb.Location = New-Object System.Drawing.Point(14, 12)
$script:tb.Size = New-Object System.Drawing.Size(420, 32)
$script:tb.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$script:tb.BackColor = [System.Drawing.Color]::FromArgb(27, 35, 61)
$script:tb.ForeColor = [System.Drawing.Color]::White
$script:tb.Font = $script:fntMsg
$inputRow.Controls.Add($script:tb)
$send = New-Object System.Windows.Forms.Button
$send.Text = '发送'
$send.Location = New-Object System.Drawing.Point(442, 10)
$send.Size = New-Object System.Drawing.Size(64, 34)
$send.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$send.BackColor = $C_ME
$send.ForeColor = [System.Drawing.Color]::White
$send.Font = $script:fntChip
$send.Cursor = [System.Windows.Forms.Cursors]::Hand
$send.Add_Click({ param($s, $e) SendInput })
$inputRow.Controls.Add($send)

$foot = New-Object System.Windows.Forms.Panel
$foot.Height = 34
$foot.BackColor = $C_BG
$script:ctxLbl = New-Object System.Windows.Forms.Label
$script:ctxLbl.Text = '对话记录: 0'
$script:ctxLbl.ForeColor = $C_INK3
$script:ctxLbl.Font = $script:fntSmall
$script:ctxLbl.AutoSize = $true
$script:ctxLbl.Location = New-Object System.Drawing.Point(14, 8)
$foot.Controls.Add($script:ctxLbl)
$resetLnk = New-Object System.Windows.Forms.LinkLabel
$resetLnk.Text = '重置对话'
$resetLnk.AutoSize = $true
$resetLnk.LinkColor = $C_INK3
$resetLnk.ActiveLinkColor = $C_ACC2
$resetLnk.Font = $script:fntSmall
$resetLnk.Location = New-Object System.Drawing.Point(438, 8)
$resetLnk.Add_LinkClicked({ param($s, $e) ResetMsgs })
$foot.Controls.Add($resetLnk)

$script:panel.Controls.Add($script:mp)
$script:panel.Controls.Add($quick)
$script:panel.Controls.Add($inputRow)
$script:panel.Controls.Add($foot)
$script:panel.Controls.Add($head)
$script:mp.Dock = 'Fill'
$quick.Dock = 'Bottom'
$inputRow.Dock = 'Bottom'
$foot.Dock = 'Bottom'
$head.Dock = 'Top'

$script:tb.Add_KeyDown({
  param($s, $e)
  if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter) { $e.SuppressKeyPress = $true; SendInput }
})

# ---------------- 本地问答规则 ----------------
$script:rules = @(
  @{ k = @('你好', 'hi', 'hello', '在吗', '在不在'); r = '你好呀！我是面试小助手，可以问我：怎么开始模拟面试、题库怎么用、语音作答、自评标准、复盘报告等问题。' },
  @{ k = @('开始', '怎么练', '如何开始', '怎么用', '如何使用', '流程'); r = "流程很简单：`n1. 点顶部「开始模拟面试」`n2. 选择场景、题数和每题时间`n3. 限时作答（支持语音输入）`n4. 对照参考答案自评打分`n5. 生成复盘报告，看自己的短板" },
  @{ k = @('题库', '题目', '有哪些题', '多少题'); r = '题库覆盖 5 大场景：求职实习、技术开发、数据分析、产品运营、通用行为。每题都带考察点、作答技巧和参考回答。' },
  @{ k = @('语音', '麦克风', '说话', '语音输入'); r = '在面试作答框右下角有麦克风按钮，点击后说话即可自动转文字（需要浏览器支持并授权麦克风，推荐 Edge/Chrome）。识别结果会直接填进作答框，可以再手动修改。' },
  @{ k = @('自评', '评分', '打分', '几颗星'); r = "每题作答后会展示参考要点，按 1-5 星给自己打分：`n1 星 完全没思路`n2 星 说了一点但不全`n3 星 覆盖主要要点`n4 星 要点全+表达顺`n5 星 亮点突出、可迁移" },
  @{ k = @('复盘', '报告', '统计', '记录'); r = '每场训练结束后会生成复盘报告：完成题数、平均自评、总用时、累计场次，还有教练点评和逐题回顾。首页也能看到累计统计数据。' },
  @{ k = @('计时', '时间', '限时', '倒计时'); r = '开始训练前可以选每题限时：60 / 90 / 120 秒。超时会自动提交当前答案。建议先求完整再求速度。' },
  @{ k = @('自我介绍'); r = '自我介绍万能三段式：我是谁（专业+标签）→ 我有什么（成绩/竞赛/项目）→ 为什么适合（岗位匹配）。控制在 1-2 分钟，结尾落到岗位价值。题库里有 5 个不同方向的自我介绍示范。' },
  @{ k = @('紧张', '害怕', '怯场'); r = '紧张很正常！三个小技巧：1）把面试当聊天而不是考试；2）提前把自我介绍练到脱口而出；3）每天来这里抽签看运势 + 随机快答一题，低成本练胆量。' },
  @{ k = @('头像', '昵称', '改名', '个人中心'); r = '点右上角你的头像，就能打开个人中心：改昵称、换头像、签到打卡、看成就进度。' },
  @{ k = @('主题', '深浅色', '夜间模式', '白底'); r = '点右上角设置可以切换深色 / 浅色主题，切换后全站生效。' },
  @{ k = @('反馈', '官方', '建议', 'bug'); r = '可以点右上角信封图标或页面下方按钮，把问题直接发给官方，称呼、联系方式、问题描述三项必填。' },
  @{ k = @('登录', '账号', '注册'); r = '点击右上角「登录」可以注册本地账号：账号 3-20 位字母/数字/下划线，密码至少 6 位，再输入图形验证码即可。不想填表可以点「游客快速登录」。' }
)
function GetLocalReply([string]$q) {
  $t = $q.ToLower()
  foreach ($r in $script:rules) {
    foreach ($kw in $r.k) {
      if ($t.Contains($kw.ToLower())) { return $r.r }
    }
  }
  return '这个问题我暂时答不上来。你可以换个说法问我（比如"怎么开始面试""题库在哪里"），或者在网页里把问题发给官方。'
}

$script:thinkTimer = New-Object System.Windows.Forms.Timer
$script:thinkTimer.Interval = 400
$script:thinkTimer.Add_Tick({
  $script:thinkTimer.Stop()
  $q = $script:pending
  $script:pending = $null
  if (!$q) { return }
  if ($script:msgs.Count -ge 2) {
    $script:msgs = @($script:msgs[0..($script:msgs.Count - 2)])
  }
  AddMsg (GetLocalReply $q) $false
})

function BeginAnswer([string]$q) {
  if (!$q) { return }
  AddMsg $q $true
  AddMsg '正在思考…' $false
  $script:pending = $q
  $script:thinkTimer.Start()
}

function SendInput {
  $v = $script:tb.Text.Trim()
  if (!$v) { return }
  $script:tb.Text = ''
  BeginAnswer $v
}

function PlacePanel {
  $pt = New-Object System.Drawing.Point(($script:ball.Left + 40), ($script:ball.Top + 40))
  $wa2 = [System.Windows.Forms.Screen]::FromPoint($pt).WorkingArea
  $pw = $script:panel.Width; $ph = $script:panel.Height
  $x = $script:ball.Left + $script:ball.Width - $pw
  $y = $script:ball.Top - $ph - 12
  if ($y -lt ($wa2.Top + 8)) { $y = $script:ball.Top + $script:ball.Height + 12 }
  $x = [Math]::Max(($wa2.Left + 8), [Math]::Min($x, ($wa2.Right - $pw - 8)))
  $y = [Math]::Max(($wa2.Top + 8), [Math]::Min($y, ($wa2.Bottom - $ph - 8)))
  $script:panel.Location = New-Object System.Drawing.Point($x, $y)
}

function TogglePanel {
  if ($script:panel.Visible) {
    $script:panel.Hide()
  } else {
    PlacePanel
    $script:panel.Show()
    $script:panel.Activate()
    $script:tb.Focus()
  }
  $script:dot = $false
  $script:ball.Invalidate()
}

# ---------------- 右键菜单 ----------------
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miOpen = $menu.Items.Add('打开 AI 助手')
$miOpen.Add_Click({ if (!$script:panel.Visible) { TogglePanel } })
$miExit = $menu.Items.Add('退出桌面助手')
$miExit.Add_Click({
  $script:enabled = $false
  SaveCfg
  # 留出一个轮询周期，确保后台服务读到 enabled=0 后不会把悬浮球重新拉起
  Start-Sleep -Milliseconds 1200
  $script:exiting = $true
  $script:watchTimer.Stop()
  try { $script:panel.Close() } catch {}
  $script:ball.Close()
})

$script:ball.Add_MouseUp({
  param($s, $e)
  if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Left) {
    if ($script:drag) {
      $script:drag = $false
      if ($script:moved) {
        Set-Content -Path $script:posFile -Value "$($script:ball.Left),$($script:ball.Top)" -Encoding ASCII
      } else {
        TogglePanel
      }
    }
  } elseif ($e.Button -eq [System.Windows.Forms.MouseButtons]::Right) {
    $menu.Show($script:ball, $e.Location)
  }
})

$tip = New-Object System.Windows.Forms.ToolTip
$tip.SetToolTip($script:ball, '拖动移动 · 点击打开助手 · 右键打开/退出')

# ---------------- 网页窗口联动 ----------------
function SiteWindowOpen {
  $script:siteSeen = $false
  $me = $PID
  [W32A]::EnumWindows({
    param($h, $l)
    if ([W32A]::IsWindowVisible($h) -and -not [W32A]::IsIconic($h)) {
      $procId = 0
      [W32A]::GetWindowThreadProcessId($h, [ref]$procId) | Out-Null
      if ($procId -ne $me) {
        $sb = New-Object System.Text.StringBuilder 512
        [W32A]::GetWindowText($h, $sb, $sb.Capacity) | Out-Null
        $t = $sb.ToString()
        if ($t.Contains('模拟面试训练营') -or $t.Contains('AI 面试助手')) {
          $script:siteSeen = $true
          return $false
        }
      }
    }
    return $true
  }, [IntPtr]::Zero) | Out-Null
  return $script:siteSeen
}

$script:watchTimer = New-Object System.Windows.Forms.Timer
$script:watchTimer.Interval = 1200
$script:watchTimer.Add_Tick({
  if ($script:exiting) { return }
  RefreshCfg
  $site = SiteWindowOpen
  if ($script:autoHide -and $site) {
    if ($script:panel.Visible) { $script:panel.Hide() }
    if ($script:ball.Visible) { $script:ball.Hide() }
  } else {
    if (!$script:ball.Visible) {
      $script:ball.Show()
      [W32A]::SetWindowPos($script:ball.Handle, [IntPtr]::new(-1), 0, 0, 0, 0, 0x0001 -bor 0x0002) | Out-Null
    }
  }
})

ResetMsgs
$script:watchTimer.Start()
[System.Windows.Forms.Application]::Run($script:ball)
